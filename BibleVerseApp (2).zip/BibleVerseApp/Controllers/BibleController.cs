﻿using BibleVerseApp.Models;
using BibleVerseApp.Services.BusinessLogic;
using Microsoft.AspNetCore.Mvc;

namespace BibleVerseApp.Controllers
{
    public class BibleController : Controller
    {
        // Initialize the default view
        public IActionResult Index()
        {
            return View();
        }

        // The HttpPost attribute indicates that this action method responds to HTTP POST requests.
        // This allows the method to map submitted form data to model properties.
        [HttpPost]
        public IActionResult Index([Bind] VerseSearchModel objSearch)
        {
            // Create a new list to hold the search results
            List<BibleVerseModel> searchResults = new List<BibleVerseModel>();

            // Check if the model state is valid to ensure all the required fields are filled in.
            // ModelState is a property in ASP.NET Core that represents the state of model binding.
            if (ModelState.IsValid)
            {
                // Instantiate the business layer
                BusinessLogic sendSearchCrit = new BusinessLogic();

                // Get all matching verses
                searchResults = sendSearchCrit.GetAllVerses(objSearch).ToList();
            }

            // Pass the search results back to the view
            return View(searchResults);
        }
    }
}
