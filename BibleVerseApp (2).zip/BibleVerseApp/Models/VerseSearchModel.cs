﻿namespace BibleVerseApp.Models
{
    public class VerseSearchModel
    {
        //thi smodel ii sused to define the prop 
        // used when the are seraching for verse bible 
        //

        public string? Testament {  get; set; }
        public string? BlibleVersion { get; set; }
        
        public string? Text { get; set; }
    }


    
}
