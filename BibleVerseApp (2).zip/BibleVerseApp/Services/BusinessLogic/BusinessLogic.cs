﻿using BibleVerseApp.Models;
using BibleVerseApp.Services.DataAccess;

namespace BibleVerseApp.Services.BusinessLogic
{
    public class BusinessLogic
    {
        /// <summary>
        /// this soing to get all bible verses that match a sprcfic search critera . 
        /// </summary>
        /// <param name="passSearchCritera"></param>
        /// <returns></returns>
        public IEnumerable<BibleVerseModel> GetAllVerses(VerseSearchModel  
            passSearchCritera)
        {
            // intanize the data acces layer
            BibleData passToDataLayer = new BibleData();


            //use the object to call the getBible verses 
            IEnumerable<BibleVerseModel> allVerse = passToDataLayer.GetBibleVerse
                (passSearchCritera);

            return allVerse;
        }
    }
}
