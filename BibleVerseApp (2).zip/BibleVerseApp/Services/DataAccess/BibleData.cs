﻿using BibleVerseApp.Models;
using BibleVerseApp.Services.Utilities;
using Microsoft.Data.SqlClient;

namespace BibleVerseApp.Services.DataAccess
{
    // This class BibleData retrieves Bible data from the DatabaseManager.
    public class BibleData : DatabaseManager
    {
        // This method retrieves Bible verses based on search criteria.
        public IEnumerable<BibleVerseModel> GetBibleVerse(VerseSearchModel searchCriteria)
        {
            // Declare and initialize variables.
            string testamentSearch = "";
            string query = "";

            // Create a list to hold the search results.
            List<BibleVerseModel> searchResults = new List<BibleVerseModel>();

            // Ensure BibleVersion has a valid value, defaulting to "dbo.t_kjv" if not set.
            string tableName = string.IsNullOrEmpty(searchCriteria.BlibleVersion)
                ? "dbo.t_kjv"
                : $"dbo.{searchCriteria.BlibleVersion}";

            // Using the connection string to connect to the SQL database.
            using (SqlConnection connection = new SqlConnection(ConnString))
            {
                try
                {
                    // Open the database connection.
                    connection.Open();

                    // Determine the testament filter based on the search criteria.
                    if (searchCriteria.Testament == "OT")
                    {
                        testamentSearch = "AND key_english.t = 'OT'";
                    }
                    else if (searchCriteria.Testament == "NT")
                    {
                        testamentSearch = "AND key_english.t = 'NT'";
                    }
                    else
                    {
                        testamentSearch = ""; // No testament filter.
                    }

                    // Define the SQL query dynamically, inserting the Bible version, search text, and testament filter.
                    query = $@"
SELECT 
    bible.t AS Text, 
    bible.b, 
    bible.c AS Chapter, 
    bible.v AS Verse, 
    key_english.n AS Book, 
    key_english.t AS Testament, 
    key_english.g, 
    key_genre_english.g, 
    key_genre_english.n AS Genre
FROM {tableName} bible
JOIN dbo.key_english
    ON bible.b = key_english.b
JOIN dbo.key_genre_english
    ON key_english.g = key_genre_english.g
WHERE bible.t LIKE @SearchText
    {testamentSearch}
ORDER BY 
    bible.b, 
    Chapter, 
    Verse";

                    // Debug: Output the generated query for validation.
                    Console.WriteLine(query);

                    // Execute the query and retrieve the results.
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameter for the search text to prevent SQL injection.
                        command.Parameters.AddWithValue("@SearchText", $"%{searchCriteria.Text}%");

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Create a new BibleVerseModel instance to store the current verse.
                                BibleVerseModel verse = new BibleVerseModel
                                {
                                    BookName = reader["Book"].ToString(),
                                    Chapter = Convert.ToInt32(reader["Chapter"]),
                                    Verse = Convert.ToInt32(reader["Verse"]),
                                    Genre = reader["Genre"].ToString(),
                                    OT_NT = reader["Testament"].ToString() == "OT" ? "Old Testament" : "New Testament",
                                    Text = reader["Text"].ToString()
                                };

                                // Add the verse to the master list.
                                searchResults.Add(verse);
                            }
                        }
                    }
                }
                catch (SqlException ex)
                {
                    // Log SQL-specific errors for debugging purposes.
                    Console.WriteLine($"SQL Error: {ex.Message}");
                }
                catch (Exception ex)
                {
                    // Log any general errors.
                    Console.WriteLine($"General Error: {ex.Message}");
                }
            }

            // Return the search results.
            return searchResults;
        }
    }
}
