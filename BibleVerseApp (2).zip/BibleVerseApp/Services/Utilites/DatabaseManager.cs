﻿namespace BibleVerseApp.Services.Utilities
{
    public class DatabaseManager
    {
        // Define the class property
        public string ConnString { get; set; }

        /// <summary>
        /// Constructor to set the database connection string
        /// </summary>
        public DatabaseManager()
        {
            //  connection string with correct 
            this.ConnString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Bible;Integrated Security=True;Connect Timeout=30;Encrypt=False;";
        }
    }
}
